package ciopper90.recorder;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.util.Log;

public class Record extends Thread{

	private final int bufferSize;
	private final AudioRecord audioRecord;
	private final byte[] audioBuffer=new byte[24576];
	private int sampleRateInHz=11025;
	private boolean active;
	private Context context;
	private String evento;
	private AndNotification n;

	public Record(Context cont){
		int channelConfig=AudioFormat.CHANNEL_IN_MONO;
		int audioFormat=AudioFormat.ENCODING_PCM_16BIT;
		context=cont;
		//bufferSize = AudioRecord.getMinBufferSize(sampleRateInHz, channelConfig, audioFormat);
		bufferSize=4096;
		audioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC,sampleRateInHz, channelConfig, audioFormat, bufferSize);
		n= new AndNotification();
	}


	@Override
	public void destroy() {
		active=false;
		//super.destroy();
	}

	@Override
	public synchronized void start() {
		active=true;
		super.start();
	}

	public void run(){
		int i=0;
		byte [][] temp=new byte[(audioBuffer.length/bufferSize)][bufferSize];
		Log.d("dimensione", (audioBuffer.length/bufferSize) + "");
		Log.d(bufferSize+"", audioBuffer.length+"");
		while(active){
			Log.d("thread", "start record");
			while(audioBuffer.length>i*bufferSize){
				audioRecord.startRecording();
				audioRecord.read(temp[i], 0, bufferSize);
				audioRecord.stop();
				i++;
			}
			for(int a=0;a<audioBuffer.length;a++){
				int indice=a/bufferSize;
				audioBuffer[a]=temp[indice][a-indice*bufferSize];				
			}		


			i=0;
			Log.d("thread", "end record");
			Log.d("thread", "start elaborazione");
			Log.d("thread", "stop elaborazione");
			int [] d=Feature.feature(audioBuffer,sampleRateInHz,context);			
			//calcolo della media dei 3 vettori

			//istanzio vettore
			int [] count=new int[7];
			for(int n=0;n<count.length;n++)
				count[n]=0;

			//incremento in base alle occorrenze
			for(int n=0;n<d.length;n++){
				count[d[n]]++;
			}
			//cerco massima
			int max=0,element=0;
			for(int n=0;n<count.length;n++){
				if(count[n]>max){
					max=count[n];
					element=n;
				}
			}
			
			String [] elemento={"parco","lezione","treno","tv","auto","ristorante","strada"};
			String scelta=elemento[element];

			if(evento==null){
				n.notify(scelta, context);		
			}else{
				if(evento!=scelta){
					n.notify(scelta, context);		
					evento=scelta;
				}
			}
			try {
				sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
