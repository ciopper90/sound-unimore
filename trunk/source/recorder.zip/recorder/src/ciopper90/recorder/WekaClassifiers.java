package ciopper90.recorder;


class WekaClassifier {

	/*
	 * 0 parco
	 * 1 lezione
	 * 2 treno
	 * 3 tv
	 * 4 auto
	 * 5 ristorante
	 * 6 strada
	 * 
	 */

	public static String classify(Object[] i)
			throws Exception {

		double p = Double.NaN;
		String [] elemento={"parco","lezione","treno","tv","auto","ristorante","strada"};
		p = WekaClassifier.N34b8aad80(i);
		return elemento[(int) p];
	}
	static double N34b8aad80(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 4;
		} else if (((Double) i[2]).doubleValue() <= 0.10922) {
			p = WekaClassifier.N47d865f21(i);
		} else if (((Double) i[2]).doubleValue() > 0.10922) {
			p = WekaClassifier.N10ac16b518(i);
		} 
		return p;
	}
	static double N47d865f21(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 4;
		} else if (((Double) i[1]).doubleValue() <= 542.0) {
			p = WekaClassifier.N500d17b72(i);
		} else if (((Double) i[1]).doubleValue() > 542.0) {
			p = WekaClassifier.N7d47e16a13(i);
		} 
		return p;
	}
	static double N500d17b72(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 4;
		} else if (((Double) i[0]).doubleValue() <= 14.209755) {
			p = WekaClassifier.Nb9018703(i);
		} else if (((Double) i[0]).doubleValue() > 14.209755) {
			p = WekaClassifier.N1e5ca0e46(i);
		} 
		return p;
	}
	static double Nb9018703(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 4;
		} else if (((Double) i[2]).doubleValue() <= 0.051064) {
			p = 4;
		} else if (((Double) i[2]).doubleValue() > 0.051064) {
			p = WekaClassifier.N213466fe4(i);
		} 
		return p;
	}
	static double N213466fe4(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 4;
		} else if (((Double) i[2]).doubleValue() <= 0.056738) {
			p = 4;
		} else if (((Double) i[2]).doubleValue() > 0.056738) {
			p = WekaClassifier.N7755beb95(i);
		} 
		return p;
	}
	static double N7755beb95(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() <= 469.0) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() > 469.0) {
			p = 4;
		} 
		return p;
	}
	static double N1e5ca0e46(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() <= 482.0) {
			p = WekaClassifier.N5346e84e7(i);
		} else if (((Double) i[1]).doubleValue() > 482.0) {
			p = WekaClassifier.N49de002d10(i);
		} 
		return p;
	}
	static double N5346e84e7(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 2;
		} else if (((Double) i[2]).doubleValue() <= 0.083688) {
			p = WekaClassifier.N543d83988(i);
		} else if (((Double) i[2]).doubleValue() > 0.083688) {
			p = WekaClassifier.N128a9b5d9(i);
		} 
		return p;
	}
	static double N543d83988(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() <= 23.495961) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() > 23.495961) {
			p = 3;
		} 
		return p;
	}
	static double N128a9b5d9(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() <= 28.138257) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() > 28.138257) {
			p = 3;
		} 
		return p;
	}
	static double N49de002d10(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 4;
		} else if (((Double) i[0]).doubleValue() <= 21.718918) {
			p = WekaClassifier.Ndddb03e11(i);
		} else if (((Double) i[0]).doubleValue() > 21.718918) {
			p = 3;
		} 
		return p;
	}
	static double Ndddb03e11(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 4;
		} else if (((Double) i[0]).doubleValue() <= 18.843628) {
			p = WekaClassifier.N555dbd8e12(i);
		} else if (((Double) i[0]).doubleValue() > 18.843628) {
			p = 2;
		} 
		return p;
	}
	static double N555dbd8e12(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 4;
		} else if (((Double) i[1]).doubleValue() <= 514.0) {
			p = 4;
		} else if (((Double) i[1]).doubleValue() > 514.0) {
			p = 3;
		} 
		return p;
	}
	static double N7d47e16a13(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 3;
		} else if (((Double) i[1]).doubleValue() <= 682.0) {
			p = WekaClassifier.N7a20366714(i);
		} else if (((Double) i[1]).doubleValue() > 682.0) {
			p = WekaClassifier.N3ed0f9db16(i);
		} 
		return p;
	}
	static double N7a20366714(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 3;
		} else if (((Double) i[1]).doubleValue() <= 647.0) {
			p = 3;
		} else if (((Double) i[1]).doubleValue() > 647.0) {
			p = WekaClassifier.N58d3e2d415(i);
		} 
		return p;
	}
	static double N58d3e2d415(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() <= 674.0) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() > 674.0) {
			p = 3;
		} 
		return p;
	}
	static double N3ed0f9db16(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() <= 3.358873) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() > 3.358873) {
			p = WekaClassifier.N9c3b91517(i);
		} 
		return p;
	}
	static double N9c3b91517(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 3;
		} else if (((Double) i[1]).doubleValue() <= 690.0) {
			p = 3;
		} else if (((Double) i[1]).doubleValue() > 690.0) {
			p = 0;
		} 
		return p;
	}
	static double N10ac16b518(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 5;
		} else if (((Double) i[1]).doubleValue() <= 474.0) {
			p = WekaClassifier.N1206cda019(i);
		} else if (((Double) i[1]).doubleValue() > 474.0) {
			p = WekaClassifier.N59a15c1676(i);
		} 
		return p;
	}
	static double N1206cda019(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() <= 38.069201) {
			p = WekaClassifier.N7ca5cc9e20(i);
		} else if (((Double) i[0]).doubleValue() > 38.069201) {
			p = WekaClassifier.N40c5590526(i);
		} 
		return p;
	}
	static double N7ca5cc9e20(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() <= 443.0) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() > 443.0) {
			p = WekaClassifier.N691cd90021(i);
		} 
		return p;
	}
	static double N691cd90021(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() <= 29.123389) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() > 29.123389) {
			p = WekaClassifier.N64eac4e922(i);
		} 
		return p;
	}
	static double N64eac4e922(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 3;
		} else if (((Double) i[2]).doubleValue() <= 0.123404) {
			p = WekaClassifier.N7125d0c123(i);
		} else if (((Double) i[2]).doubleValue() > 0.123404) {
			p = WekaClassifier.N69ac68ef24(i);
		} 
		return p;
	}
	static double N7125d0c123(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() <= 34.03725) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() > 34.03725) {
			p = 1;
		} 
		return p;
	}
	static double N69ac68ef24(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 6;
		} else if (((Double) i[2]).doubleValue() <= 0.153191) {
			p = WekaClassifier.N361d591c25(i);
		} else if (((Double) i[2]).doubleValue() > 0.153191) {
			p = 2;
		} 
		return p;
	}
	static double N361d591c25(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() <= 445.0) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() > 445.0) {
			p = 6;
		} 
		return p;
	}
	static double N40c5590526(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 5;
		} else if (((Double) i[1]).doubleValue() <= 444.0) {
			p = WekaClassifier.N5c57787b27(i);
		} else if (((Double) i[1]).doubleValue() > 444.0) {
			p = WekaClassifier.N33b1603e52(i);
		} 
		return p;
	}
	static double N5c57787b27(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 5;
		} else if (((Double) i[0]).doubleValue() <= 51.289704) {
			p = WekaClassifier.N72a7029928(i);
		} else if (((Double) i[0]).doubleValue() > 51.289704) {
			p = WekaClassifier.N564cce2e37(i);
		} 
		return p;
	}
	static double N72a7029928(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 5;
		} else if (((Double) i[2]).doubleValue() <= 0.157447) {
			p = WekaClassifier.N329bc59d29(i);
		} else if (((Double) i[2]).doubleValue() > 0.157447) {
			p = WekaClassifier.N5848715632(i);
		} 
		return p;
	}
	static double N329bc59d29(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 47.448625) {
			p = WekaClassifier.N10cae06030(i);
		} else if (((Double) i[0]).doubleValue() > 47.448625) {
			p = 5;
		} 
		return p;
	}
	static double N10cae06030(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() <= 431.0) {
			p = WekaClassifier.N7750c73c31(i);
		} else if (((Double) i[1]).doubleValue() > 431.0) {
			p = 1;
		} 
		return p;
	}
	static double N7750c73c31(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 5;
		} else if (((Double) i[0]).doubleValue() <= 42.64148) {
			p = 5;
		} else if (((Double) i[0]).doubleValue() > 42.64148) {
			p = 1;
		} 
		return p;
	}
	static double N5848715632(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() <= 434.0) {
			p = WekaClassifier.N7c08f26133(i);
		} else if (((Double) i[1]).doubleValue() > 434.0) {
			p = WekaClassifier.N277e524b36(i);
		} 
		return p;
	}
	static double N7c08f26133(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() <= 49.862899) {
			p = WekaClassifier.N2f60fde534(i);
		} else if (((Double) i[0]).doubleValue() > 49.862899) {
			p = 1;
		} 
		return p;
	}
	static double N2f60fde534(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 6;
		} else if (((Double) i[2]).doubleValue() <= 0.194326) {
			p = WekaClassifier.N8bcddb035(i);
		} else if (((Double) i[2]).doubleValue() > 0.194326) {
			p = 2;
		} 
		return p;
	}
	static double N8bcddb035(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() <= 47.132512) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() > 47.132512) {
			p = 6;
		} 
		return p;
	}
	static double N277e524b36(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 5;
		} else if (((Double) i[0]).doubleValue() <= 48.353676) {
			p = 5;
		} else if (((Double) i[0]).doubleValue() > 48.353676) {
			p = 6;
		} 
		return p;
	}
	static double N564cce2e37(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 5;
		} else if (((Double) i[1]).doubleValue() <= 432.0) {
			p = 5;
		} else if (((Double) i[1]).doubleValue() > 432.0) {
			p = WekaClassifier.N4c745a4538(i);
		} 
		return p;
	}
	static double N4c745a4538(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 6;
		} else if (((Double) i[0]).doubleValue() <= 58.468597) {
			p = WekaClassifier.N6ad28f3939(i);
		} else if (((Double) i[0]).doubleValue() > 58.468597) {
			p = WekaClassifier.Na20d3c944(i);
		} 
		return p;
	}
	static double N6ad28f3939(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 5;
		} else if (((Double) i[2]).doubleValue() <= 0.180142) {
			p = WekaClassifier.N25b91df940(i);
		} else if (((Double) i[2]).doubleValue() > 0.180142) {
			p = WekaClassifier.N172be80542(i);
		} 
		return p;
	}
	static double N25b91df940(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 5;
		} else if (((Double) i[0]).doubleValue() <= 54.106964) {
			p = 5;
		} else if (((Double) i[0]).doubleValue() > 54.106964) {
			p = WekaClassifier.N1c5ed9c841(i);
		} 
		return p;
	}
	static double N1c5ed9c841(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() <= 0.170213) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() > 0.170213) {
			p = 5;
		} 
		return p;
	}
	static double N172be80542(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 6;
		} else if (((Double) i[2]).doubleValue() <= 0.191489) {
			p = 6;
		} else if (((Double) i[2]).doubleValue() > 0.191489) {
			p = WekaClassifier.N438dac2543(i);
		} 
		return p;
	}
	static double N438dac2543(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 5;
		} else if (((Double) i[0]).doubleValue() <= 57.131251) {
			p = 5;
		} else if (((Double) i[0]).doubleValue() > 57.131251) {
			p = 6;
		} 
		return p;
	}
	static double Na20d3c944(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 5;
		} else if (((Double) i[2]).doubleValue() <= 0.300709) {
			p = WekaClassifier.N7130365045(i);
		} else if (((Double) i[2]).doubleValue() > 0.300709) {
			p = WekaClassifier.N1a932a1b51(i);
		} 
		return p;
	}
	static double N7130365045(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 5;
		} else if (((Double) i[1]).doubleValue() <= 438.0) {
			p = WekaClassifier.N143df83e46(i);
		} else if (((Double) i[1]).doubleValue() > 438.0) {
			p = WekaClassifier.N7074b8d347(i);
		} 
		return p;
	}
	static double N143df83e46(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 5;
		} else if (((Double) i[0]).doubleValue() <= 96.601617) {
			p = 5;
		} else if (((Double) i[0]).doubleValue() > 96.601617) {
			p = 1;
		} 
		return p;
	}
	static double N7074b8d347(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 5;
		} else if (((Double) i[2]).doubleValue() <= 0.231206) {
			p = 5;
		} else if (((Double) i[2]).doubleValue() > 0.231206) {
			p = WekaClassifier.N7f125e5248(i);
		} 
		return p;
	}
	static double N7f125e5248(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 6;
		} else if (((Double) i[2]).doubleValue() <= 0.283688) {
			p = WekaClassifier.Neee9aab49(i);
		} else if (((Double) i[2]).doubleValue() > 0.283688) {
			p = 5;
		} 
		return p;
	}
	static double Neee9aab49(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 5;
		} else if (((Double) i[2]).doubleValue() <= 0.232624) {
			p = 5;
		} else if (((Double) i[2]).doubleValue() > 0.232624) {
			p = WekaClassifier.N52ec583550(i);
		} 
		return p;
	}
	static double N52ec583550(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 6;
		} else if (((Double) i[2]).doubleValue() <= 0.270922) {
			p = 6;
		} else if (((Double) i[2]).doubleValue() > 0.270922) {
			p = 1;
		} 
		return p;
	}
	static double N1a932a1b51(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 6;
		} else if (((Double) i[2]).doubleValue() <= 0.340426) {
			p = 6;
		} else if (((Double) i[2]).doubleValue() > 0.340426) {
			p = 5;
		} 
		return p;
	}
	static double N33b1603e52(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 6;
		} else if (((Double) i[2]).doubleValue() <= 0.313475) {
			p = WekaClassifier.N4225a0f553(i);
		} else if (((Double) i[2]).doubleValue() > 0.313475) {
			p = WekaClassifier.N640c40f971(i);
		} 
		return p;
	}
	static double N4225a0f553(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() <= 0.141844) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() > 0.141844) {
			p = WekaClassifier.N346a56c054(i);
		} 
		return p;
	}
	static double N346a56c054(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() <= 452.0) {
			p = WekaClassifier.N3165722255(i);
		} else if (((Double) i[1]).doubleValue() > 452.0) {
			p = WekaClassifier.N538f1db267(i);
		} 
		return p;
	}
	static double N3165722255(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 5;
		} else if (((Double) i[0]).doubleValue() <= 52.461959) {
			p = WekaClassifier.N7b282f8356(i);
		} else if (((Double) i[0]).doubleValue() > 52.461959) {
			p = WekaClassifier.N58b0277059(i);
		} 
		return p;
	}
	static double N7b282f8356(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 5;
		} else if (((Double) i[2]).doubleValue() <= 0.182979) {
			p = WekaClassifier.Nb4780a057(i);
		} else if (((Double) i[2]).doubleValue() > 0.182979) {
			p = WekaClassifier.N34d8e2958(i);
		} 
		return p;
	}
	static double Nb4780a057(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 5;
		} else if (((Double) i[2]).doubleValue() <= 0.168794) {
			p = 5;
		} else if (((Double) i[2]).doubleValue() > 0.168794) {
			p = 3;
		} 
		return p;
	}
	static double N34d8e2958(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 6;
		} else if (((Double) i[2]).doubleValue() <= 0.198582) {
			p = 6;
		} else if (((Double) i[2]).doubleValue() > 0.198582) {
			p = 2;
		} 
		return p;
	}
	static double N58b0277059(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 6;
		} else if (((Double) i[0]).doubleValue() <= 70.575076) {
			p = WekaClassifier.N14ed578d60(i);
		} else if (((Double) i[0]).doubleValue() > 70.575076) {
			p = WekaClassifier.Nb3f77f965(i);
		} 
		return p;
	}
	static double N14ed578d60(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 6;
		} else if (((Double) i[0]).doubleValue() <= 59.450704) {
			p = 6;
		} else if (((Double) i[0]).doubleValue() > 59.450704) {
			p = WekaClassifier.N6a0ef4b661(i);
		} 
		return p;
	}
	static double N6a0ef4b661(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() <= 0.191489) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() > 0.191489) {
			p = WekaClassifier.N7be40f1f62(i);
		} 
		return p;
	}
	static double N7be40f1f62(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 3;
		} else if (((Double) i[2]).doubleValue() <= 0.195745) {
			p = 3;
		} else if (((Double) i[2]).doubleValue() > 0.195745) {
			p = WekaClassifier.N399cfbc463(i);
		} 
		return p;
	}
	static double N399cfbc463(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 5;
		} else if (((Double) i[2]).doubleValue() <= 0.204255) {
			p = WekaClassifier.N71551e6864(i);
		} else if (((Double) i[2]).doubleValue() > 0.204255) {
			p = 6;
		} 
		return p;
	}
	static double N71551e6864(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 60.865326) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() > 60.865326) {
			p = 5;
		} 
		return p;
	}
	static double Nb3f77f965(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 5;
		} else if (((Double) i[2]).doubleValue() <= 0.265248) {
			p = 5;
		} else if (((Double) i[2]).doubleValue() > 0.265248) {
			p = WekaClassifier.N73dd823366(i);
		} 
		return p;
	}
	static double N73dd823366(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 6;
		} else if (((Double) i[0]).doubleValue() <= 95.647249) {
			p = 6;
		} else if (((Double) i[0]).doubleValue() > 95.647249) {
			p = 5;
		} 
		return p;
	}
	static double N538f1db267(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 6;
		} else if (((Double) i[0]).doubleValue() <= 55.605018) {
			p = WekaClassifier.N58e6bbf968(i);
		} else if (((Double) i[0]).doubleValue() > 55.605018) {
			p = 6;
		} 
		return p;
	}
	static double N58e6bbf968(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() <= 42.275328) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() > 42.275328) {
			p = WekaClassifier.N143f060869(i);
		} 
		return p;
	}
	static double N143f060869(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() <= 471.0) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() > 471.0) {
			p = WekaClassifier.N35a5019a70(i);
		} 
		return p;
	}
	static double N35a5019a70(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() <= 50.239048) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() > 50.239048) {
			p = 1;
		} 
		return p;
	}
	static double N640c40f971(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() <= 0.38156) {
			p = WekaClassifier.N607dcebf72(i);
		} else if (((Double) i[2]).doubleValue() > 0.38156) {
			p = 3;
		} 
		return p;
	}
	static double N607dcebf72(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 111.786636) {
			p = WekaClassifier.N63908f1673(i);
		} else if (((Double) i[0]).doubleValue() > 111.786636) {
			p = WekaClassifier.N4fe652175(i);
		} 
		return p;
	}
	static double N63908f1673(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() <= 99.683195) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() > 99.683195) {
			p = WekaClassifier.N27a2206b74(i);
		} 
		return p;
	}
	static double N27a2206b74(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() <= 0.348936) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() > 0.348936) {
			p = 3;
		} 
		return p;
	}
	static double N4fe652175(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 6;
		} else if (((Double) i[0]).doubleValue() <= 122.296977) {
			p = 6;
		} else if (((Double) i[0]).doubleValue() > 122.296977) {
			p = 1;
		} 
		return p;
	}
	static double N59a15c1676(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() <= 619.0) {
			p = WekaClassifier.N70a4d65277(i);
		} else if (((Double) i[1]).doubleValue() > 619.0) {
			p = WekaClassifier.Nf6f1374114(i);
		} 
		return p;
	}
	static double N70a4d65277(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() <= 0.331915) {
			p = WekaClassifier.N55f2db4478(i);
		} else if (((Double) i[2]).doubleValue() > 0.331915) {
			p = WekaClassifier.N7c3a66ef105(i);
		} 
		return p;
	}
	static double N55f2db4478(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() <= 502.0) {
			p = WekaClassifier.N3b19797179(i);
		} else if (((Double) i[1]).doubleValue() > 502.0) {
			p = WekaClassifier.N7917ef9193(i);
		} 
		return p;
	}
	static double N3b19797179(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 44.793505) {
			p = WekaClassifier.N574080780(i);
		} else if (((Double) i[0]).doubleValue() > 44.793505) {
			p = WekaClassifier.N3730b48489(i);
		} 
		return p;
	}
	static double N574080780(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() <= 483.0) {
			p = WekaClassifier.N4bb065d81(i);
		} else if (((Double) i[1]).doubleValue() > 483.0) {
			p = WekaClassifier.N1adcef6184(i);
		} 
		return p;
	}
	static double N4bb065d81(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() <= 31.435179) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() > 31.435179) {
			p = WekaClassifier.N129ec61882(i);
		} 
		return p;
	}
	static double N129ec61882(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() <= 37.122193) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() > 37.122193) {
			p = WekaClassifier.N75df5b3483(i);
		} 
		return p;
	}
	static double N75df5b3483(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() <= 0.161702) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() > 0.161702) {
			p = 2;
		} 
		return p;
	}
	static double N1adcef6184(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() <= 494.0) {
			p = WekaClassifier.N1ee7d70e85(i);
		} else if (((Double) i[1]).doubleValue() > 494.0) {
			p = WekaClassifier.N95eed5a88(i);
		} 
		return p;
	}
	static double N1ee7d70e85(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() <= 0.120567) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() > 0.120567) {
			p = WekaClassifier.N6d7e7fc86(i);
		} 
		return p;
	}
	static double N6d7e7fc86(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() <= 485.0) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() > 485.0) {
			p = WekaClassifier.N48bf54e687(i);
		} 
		return p;
	}
	static double N48bf54e687(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() <= 43.549009) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() > 43.549009) {
			p = 1;
		} 
		return p;
	}
	static double N95eed5a88(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 6;
		} else if (((Double) i[0]).doubleValue() <= 30.037118) {
			p = 6;
		} else if (((Double) i[0]).doubleValue() > 30.037118) {
			p = 3;
		} 
		return p;
	}
	static double N3730b48489(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 6;
		} else if (((Double) i[0]).doubleValue() <= 69.174447) {
			p = 6;
		} else if (((Double) i[0]).doubleValue() > 69.174447) {
			p = WekaClassifier.N5e9b626a90(i);
		} 
		return p;
	}
	static double N5e9b626a90(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 93.391721) {
			p = WekaClassifier.N2b5a4dac91(i);
		} else if (((Double) i[0]).doubleValue() > 93.391721) {
			p = 3;
		} 
		return p;
	}
	static double N2b5a4dac91(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() <= 0.252482) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() > 0.252482) {
			p = WekaClassifier.N35a16d7092(i);
		} 
		return p;
	}
	static double N35a16d7092(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 3;
		} else if (((Double) i[2]).doubleValue() <= 0.276596) {
			p = 3;
		} else if (((Double) i[2]).doubleValue() > 0.276596) {
			p = 1;
		} 
		return p;
	}
	static double N7917ef9193(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 3;
		} else if (((Double) i[2]).doubleValue() <= 0.148936) {
			p = WekaClassifier.N127156b394(i);
		} else if (((Double) i[2]).doubleValue() > 0.148936) {
			p = WekaClassifier.N4ef30b3a95(i);
		} 
		return p;
	}
	static double N127156b394(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() <= 0.126241) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() > 0.126241) {
			p = 3;
		} 
		return p;
	}
	static double N4ef30b3a95(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 85.81044) {
			p = WekaClassifier.N3666355496(i);
		} else if (((Double) i[0]).doubleValue() > 85.81044) {
			p = WekaClassifier.N1d04be13103(i);
		} 
		return p;
	}
	static double N3666355496(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() <= 0.24539) {
			p = WekaClassifier.N703739b297(i);
		} else if (((Double) i[2]).doubleValue() > 0.24539) {
			p = WekaClassifier.N52158e1a101(i);
		} 
		return p;
	}
	static double N703739b297(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() <= 587.0) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() > 587.0) {
			p = WekaClassifier.N39ad0eac98(i);
		} 
		return p;
	}
	static double N39ad0eac98(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() <= 597.0) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() > 597.0) {
			p = WekaClassifier.N109e5bc999(i);
		} 
		return p;
	}
	static double N109e5bc999(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() <= 0.207092) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() > 0.207092) {
			p = WekaClassifier.Nc9bf1a5100(i);
		} 
		return p;
	}
	static double Nc9bf1a5100(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 3;
		} else if (((Double) i[1]).doubleValue() <= 615.0) {
			p = 3;
		} else if (((Double) i[1]).doubleValue() > 615.0) {
			p = 1;
		} 
		return p;
	}
	static double N52158e1a101(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() <= 0.255319) {
			p = 1;
		} else if (((Double) i[2]).doubleValue() > 0.255319) {
			p = WekaClassifier.N5247710102(i);
		} 
		return p;
	}
	static double N5247710102(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 3;
		} else if (((Double) i[2]).doubleValue() <= 0.300709) {
			p = 3;
		} else if (((Double) i[2]).doubleValue() > 0.300709) {
			p = 1;
		} 
		return p;
	}
	static double N1d04be13103(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 3;
		} else if (((Double) i[2]).doubleValue() <= 0.307801) {
			p = 3;
		} else if (((Double) i[2]).doubleValue() > 0.307801) {
			p = WekaClassifier.N225ae047104(i);
		} 
		return p;
	}
	static double N225ae047104(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 0;
		} else if (((Double) i[0]).doubleValue() <= 102.781787) {
			p = 0;
		} else if (((Double) i[0]).doubleValue() > 102.781787) {
			p = 3;
		} 
		return p;
	}
	static double N7c3a66ef105(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 3;
		} else if (((Double) i[1]).doubleValue() <= 540.0) {
			p = WekaClassifier.N5e3c14a0106(i);
		} else if (((Double) i[1]).doubleValue() > 540.0) {
			p = WekaClassifier.N72155e4e111(i);
		} 
		return p;
	}
	static double N5e3c14a0106(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 3;
		} else if (((Double) i[2]).doubleValue() <= 0.456738) {
			p = WekaClassifier.N3a6e44b5107(i);
		} else if (((Double) i[2]).doubleValue() > 0.456738) {
			p = WekaClassifier.N1d60e50b108(i);
		} 
		return p;
	}
	static double N3a6e44b5107(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() <= 157.172044) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() > 157.172044) {
			p = 1;
		} 
		return p;
	}
	static double N1d60e50b108(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 0;
		} else if (((Double) i[0]).doubleValue() <= 152.828492) {
			p = WekaClassifier.N445d443e109(i);
		} else if (((Double) i[0]).doubleValue() > 152.828492) {
			p = WekaClassifier.N472b6582110(i);
		} 
		return p;
	}
	static double N445d443e109(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 3;
		} else if (((Double) i[1]).doubleValue() <= 488.0) {
			p = 3;
		} else if (((Double) i[1]).doubleValue() > 488.0) {
			p = 0;
		} 
		return p;
	}
	static double N472b6582110(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 0;
		} else if (((Double) i[1]).doubleValue() <= 480.0) {
			p = 0;
		} else if (((Double) i[1]).doubleValue() > 480.0) {
			p = 3;
		} 
		return p;
	}
	static double N72155e4e111(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 0;
		} else if (((Double) i[1]).doubleValue() <= 590.0) {
			p = WekaClassifier.N58e28d65112(i);
		} else if (((Double) i[1]).doubleValue() > 590.0) {
			p = 0;
		} 
		return p;
	}
	static double N58e28d65112(Object []i) {
		double p = Double.NaN;
		if (i[2] == null) {
			p = 3;
		} else if (((Double) i[2]).doubleValue() <= 0.370213) {
			p = 3;
		} else if (((Double) i[2]).doubleValue() > 0.370213) {
			p = WekaClassifier.N1b10f7a113(i);
		} 
		return p;
	}
	static double N1b10f7a113(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 0;
		} else if (((Double) i[0]).doubleValue() <= 160.802009) {
			p = 0;
		} else if (((Double) i[0]).doubleValue() > 160.802009) {
			p = 3;
		} 
		return p;
	}
	static double Nf6f1374114(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 27.809927) {
			p = WekaClassifier.N45662c96115(i);
		} else if (((Double) i[0]).doubleValue() > 27.809927) {
			p = 0;
		} 
		return p;
	}
	static double N45662c96115(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() <= 683.0) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() > 683.0) {
			p = 0;
		} 
		return p;
	}
}
