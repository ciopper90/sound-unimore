package ciopper90.recorder;

import android.content.Context;
import android.util.Log;

public class Feature {

	/*public static double[] feature(byte[] audio,int sample_rate){
		double[] a=new double[3];
		byte [][] sample=extract_sample(audio,sample_rate);
				for(int n=0;n<sample.length;n++){
					a[0]=ZeroCrossingRate2(sample[n]);
					a[1]=SpectralCentroid(sample[n],sample_rate);
					a[2]=LowEnergyFrameRate(sample[n]);
					Log.d("campione "+n, a[0]+" "+a[1]+" "+a[2]);
				}
		return a;
	}*/
	public static int[] feature(byte[] audio,int sample_rate,Context context){
		byte [][] sample=extract_sample(audio,sample_rate);
		double[][] a=new double[sample.length][2];
		Object[] c=new Object[2];
		int [] h=new int[sample.length];


		MyDatabase db=new MyDatabase(context);



		for(int n=1;n<sample.length;n++){
			a[n][1]=ZeroCrossingRate2(sample[n]);
			c[1]=ZeroCrossingRate(sample[n]);
			//a[1]=SpectralCentroid(sample[n],sample_rate);
			a[n][0]=LowEnergyFrameRate(sample[n]);
			c[0]=LowEnergyFrameRate(sample[n]);
			Log.d("campione "+n, a[n][0]+" "+a[n][1]);//+" "+a[2]);
			try {
				db.open();  //apriamo il db
				h[n]=WekaClassifier3.classify(c);
				Log.d("classify", h[n]+"");
				db.insertProduct(h[n]+"", n);
				db.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return h;
	}

	private static byte[][] extract_sample(byte[] audio,int sample_rate) {
		//number of sample
		int number_sample=4;
		//time of sample
		double time=0.064;
		//number of frame in a sample
		int number_rate=(int) (time*sample_rate);

		byte [][] temp=new byte[number_sample][number_rate];
		int n=0;
		int frame=audio.length/number_sample;
		for(int i=0;i<number_sample;i++){
			for(int k=0;k<number_rate;k++,n++){
				temp[i][k]=audio[n];
			}
			n=n+frame;

		}


		return temp;
	}

	private static double LowEnergyFrameRate(byte[] audio) {
		double sum=0;
		for(int i=0;i<audio.length-1;i++)
			sum=sum+(Math.pow(audio[i],2));
		sum=sum/audio.length;
		double rms=Math.sqrt(sum)/2;
		int lefr=0;
		for(int i=0;i<audio.length;i++){
			//if(Math.abs(audio[i])<rms){
			if(audio[i]<rms){
				lefr++;
			}
		}
		return lefr;
	}

	/*private static double SpectralCentroid(byte[] audio, int sample_rate) {
		//trasformata di laplace del segnale audio
	    Complex[] fftTempArray = new Complex[audio.length];
        for (int i=0; i<audio.length; i++)
        {
            fftTempArray[i] = new Complex(audio[i], 0);
        }

        //p = np.abs(np.fft.rfft(signal))
        Complex[] fftArray = FFT.fft(fftTempArray);
        for(int i=0;i<audio.length;i++){
        	fftArray[i]=abs(fftArray[i]);
        }
        //fine trasformata di laplace del segnale audio

        //f = np.linspace(0, sample_rate / 2.0, len(p))
        Linspace counter = new Linspace(0,sample_rate/2,fftArray.length);
        while(counter.hasNext()) {
            process(counter.getNextFloat())
        }

        int f=fftArray.length;
        double num=0,den=0;
        int i=0;
        while(counter.hasNext()||(i=(int) counter.getNextFloat())<1024) {
             num=num+(fftArray[i].times(fftArray[i]).times(i).abs());
        }
        i=0;
        counter = new Linspace(0,sample_rate/2,fftArray.length);
        while(counter.hasNext()||(i=(int) counter.getNextFloat())<1024) {
            i=(int) counter.getNextFloat();
            den=den+(fftArray[i].times(fftArray[i]).abs());
        }
        return num/den;

        	    num = den = 0.0
        	    for i in range(len(f)):
        	        num = num + (i * (p[i] * p[i]))
        	    for i in range(len(f)):
        	        den = den + ((p[i] * p[i]))

        	    sample['sc'] = num / den


		// return 0;
	}
	private static Complex abs(Complex complex) {
		if(complex.re()<0){
			complex=new Complex(-(complex.re()),0);
		}
		return complex;
	}*/

	private static double ZeroCrossingRate(byte[] audio) {
		int prima=audio[0];
		int dopo;
		double zcr=0;
		for(int i=1;i<audio.length-1;i++){
			dopo=audio[i];
			zcr=zcr+Math.abs((Math.signum(dopo)-Math.signum(prima)));
			prima=dopo;
		}
		zcr=zcr/(2*audio.length);
		return zcr;
	}

	private static double ZeroCrossingRate2(byte[] audio) {
		int prima=audio[0];
		int dopo;
		double zcr=0;
		for(int i=1;i<audio.length-1;i++){
			dopo=audio[i];
			if(prima*dopo<0)
				zcr++;
			prima=dopo;
		}
		//zcr=zcr/2;
		zcr=zcr/audio.length;
		return zcr;
	}

}
