package ciopper90.recorder;


public class WekaClassifier1 {

	public static String classify(Object[] i)
			throws Exception {

		double p = Double.NaN;
		String [] elemento={"parco","lezione","treno","tv","auto","ristorante","strada"};
		p = WekaClassifier1.N19a0ecb187(i);
		return elemento[(int) p];
	}
	static double N19a0ecb187(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 4;
		} else if (((Double) i[1]).doubleValue() <= 0.10922) {
			p = WekaClassifier1.N1413659c88(i);
		} else if (((Double) i[1]).doubleValue() > 0.10922) {
			p = WekaClassifier1.N3e848c55110(i);
		} 
		return p;
	}
	static double N1413659c88(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 4;
		} else if (((Double) i[0]).doubleValue() <= 542.0) {
			p = WekaClassifier1.N573ef1089(i);
		} else if (((Double) i[0]).doubleValue() > 542.0) {
			p = WekaClassifier1.N47cdebc0106(i);
		} 
		return p;
	}
	static double N573ef1089(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 4;
		} else if (((Double) i[1]).doubleValue() <= 0.056738) {
			p = WekaClassifier1.N7e54063b90(i);
		} else if (((Double) i[1]).doubleValue() > 0.056738) {
			p = WekaClassifier1.Nef3ecca99(i);
		} 
		return p;
	}
	static double N7e54063b90(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 4;
		} else if (((Double) i[0]).doubleValue() <= 415.0) {
			p = WekaClassifier1.N3e654c4891(i);
		} else if (((Double) i[0]).doubleValue() > 415.0) {
			p = WekaClassifier1.N3972685597(i);
		} 
		return p;
	}
	static double N3e654c4891(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 4;
		} else if (((Double) i[1]).doubleValue() <= 0.049645) {
			p = WekaClassifier1.N6c732af892(i);
		} else if (((Double) i[1]).doubleValue() > 0.049645) {
			p = WekaClassifier1.N73fe415196(i);
		} 
		return p;
	}
	static double N6c732af892(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 4;
		} else if (((Double) i[0]).doubleValue() <= 379.0) {
			p = 4;
		} else if (((Double) i[0]).doubleValue() > 379.0) {
			p = WekaClassifier1.N7d0a376793(i);
		} 
		return p;
	}
	static double N7d0a376793(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() <= 401.0) {
			p = WekaClassifier1.N29bb8b5394(i);
		} else if (((Double) i[0]).doubleValue() > 401.0) {
			p = 4;
		} 
		return p;
	}
	static double N29bb8b5394(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() <= 0.029787) {
			p = WekaClassifier1.N57b80b8c95(i);
		} else if (((Double) i[1]).doubleValue() > 0.029787) {
			p = 2;
		} 
		return p;
	}
	static double N57b80b8c95(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() <= 0.025532) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() > 0.025532) {
			p = 4;
		} 
		return p;
	}
	static double N73fe415196(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() <= 399.0) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() > 399.0) {
			p = 2;
		} 
		return p;
	}
	static double N3972685597(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 4;
		} else if (((Double) i[1]).doubleValue() <= 0.051064) {
			p = 4;
		} else if (((Double) i[1]).doubleValue() > 0.051064) {
			p = WekaClassifier1.N61fc1ea98(i);
		} 
		return p;
	}
	static double N61fc1ea98(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() <= 429.0) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() > 429.0) {
			p = 4;
		} 
		return p;
	}
	static double Nef3ecca99(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() <= 477.0) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() > 477.0) {
			p = WekaClassifier1.N303ec971100(i);
		} 
		return p;
	}
	static double N303ec971100(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 4;
		} else if (((Double) i[1]).doubleValue() <= 0.075177) {
			p = 4;
		} else if (((Double) i[1]).doubleValue() > 0.075177) {
			p = WekaClassifier1.N6a1b3275101(i);
		} 
		return p;
	}
	static double N6a1b3275101(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 490.0) {
			p = WekaClassifier1.N1f8dd5bf102(i);
		} else if (((Double) i[0]).doubleValue() > 490.0) {
			p = WekaClassifier1.N78c4092f104(i);
		} 
		return p;
	}
	static double N1f8dd5bf102(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 487.0) {
			p = WekaClassifier1.N18cbfec8103(i);
		} else if (((Double) i[0]).doubleValue() > 487.0) {
			p = 4;
		} 
		return p;
	}
	static double N18cbfec8103(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() <= 484.0) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() > 484.0) {
			p = 1;
		} 
		return p;
	}
	static double N78c4092f104(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 3;
		} else if (((Double) i[1]).doubleValue() <= 0.100709) {
			p = 3;
		} else if (((Double) i[1]).doubleValue() > 0.100709) {
			p = WekaClassifier1.Ne372a9a105(i);
		} 
		return p;
	}
	static double Ne372a9a105(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 514.0) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() > 514.0) {
			p = 3;
		} 
		return p;
	}
	static double N47cdebc0106(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() <= 682.0) {
			p = WekaClassifier1.N2030af14107(i);
		} else if (((Double) i[0]).doubleValue() > 682.0) {
			p = WekaClassifier1.N74734fed109(i);
		} 
		return p;
	}
	static double N2030af14107(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() <= 647.0) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() > 647.0) {
			p = WekaClassifier1.N5c365a8e108(i);
		} 
		return p;
	}
	static double N5c365a8e108(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 674.0) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() > 674.0) {
			p = 3;
		} 
		return p;
	}
	static double N74734fed109(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() <= 690.0) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() > 690.0) {
			p = 0;
		} 
		return p;
	}
	static double N3e848c55110(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 5;
		} else if (((Double) i[0]).doubleValue() <= 474.0) {
			p = WekaClassifier1.N70194083111(i);
		} else if (((Double) i[0]).doubleValue() > 474.0) {
			p = WekaClassifier1.N22656f19142(i);
		} 
		return p;
	}
	static double N70194083111(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 5;
		} else if (((Double) i[0]).doubleValue() <= 442.0) {
			p = WekaClassifier1.N9da91f4112(i);
		} else if (((Double) i[0]).doubleValue() > 442.0) {
			p = WekaClassifier1.N5abc5c2c116(i);
		} 
		return p;
	}
	static double N9da91f4112(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() <= 0.148936) {
			p = WekaClassifier1.N6ca42f39113(i);
		} else if (((Double) i[1]).doubleValue() > 0.148936) {
			p = 5;
		} 
		return p;
	}
	static double N6ca42f39113(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() <= 0.139007) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() > 0.139007) {
			p = WekaClassifier1.Nf187ee8114(i);
		} 
		return p;
	}
	static double Nf187ee8114(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 5;
		} else if (((Double) i[0]).doubleValue() <= 422.0) {
			p = 5;
		} else if (((Double) i[0]).doubleValue() > 422.0) {
			p = WekaClassifier1.N1133b916115(i);
		} 
		return p;
	}
	static double N1133b916115(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() <= 434.0) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() > 434.0) {
			p = 5;
		} 
		return p;
	}
	static double N5abc5c2c116(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() <= 0.15461) {
			p = WekaClassifier1.N4477b3e117(i);
		} else if (((Double) i[1]).doubleValue() > 0.15461) {
			p = WekaClassifier1.N3124f9f4127(i);
		} 
		return p;
	}
	static double N4477b3e117(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() <= 0.113475) {
			p = WekaClassifier1.N70ec25a3118(i);
		} else if (((Double) i[1]).doubleValue() > 0.113475) {
			p = WekaClassifier1.N3f2dff6120(i);
		} 
		return p;
	}
	static double N70ec25a3118(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() <= 0.112057) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() > 0.112057) {
			p = WekaClassifier1.N1f9b2a40119(i);
		} 
		return p;
	}
	static double N1f9b2a40119(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() <= 467.0) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() > 467.0) {
			p = 2;
		} 
		return p;
	}
	static double N3f2dff6120(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 2;
		} else if (((Double) i[1]).doubleValue() <= 0.147518) {
			p = WekaClassifier1.N3e4d9180121(i);
		} else if (((Double) i[1]).doubleValue() > 0.147518) {
			p = WekaClassifier1.N1117cb50126(i);
		} 
		return p;
	}
	static double N3e4d9180121(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() <= 462.0) {
			p = WekaClassifier1.N568b8a74122(i);
		} else if (((Double) i[0]).doubleValue() > 462.0) {
			p = WekaClassifier1.N632ef20f123(i);
		} 
		return p;
	}
	static double N568b8a74122(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() <= 0.114894) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() > 0.114894) {
			p = 2;
		} 
		return p;
	}
	static double N632ef20f123(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 465.0) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() > 465.0) {
			p = WekaClassifier1.N1f15e9a8124(i);
		} 
		return p;
	}
	static double N1f15e9a8124(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() <= 0.139007) {
			p = WekaClassifier1.N579f2489125(i);
		} else if (((Double) i[1]).doubleValue() > 0.139007) {
			p = 6;
		} 
		return p;
	}
	static double N579f2489125(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() <= 0.130496) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() > 0.130496) {
			p = 1;
		} 
		return p;
	}
	static double N1117cb50126(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() <= 460.0) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() > 460.0) {
			p = 2;
		} 
		return p;
	}
	static double N3124f9f4127(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() <= 0.313475) {
			p = WekaClassifier1.N72961b60128(i);
		} else if (((Double) i[1]).doubleValue() > 0.313475) {
			p = WekaClassifier1.N642e1d80138(i);
		} 
		return p;
	}
	static double N72961b60128(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 6;
		} else if (((Double) i[0]).doubleValue() <= 452.0) {
			p = WekaClassifier1.N5cdf7665129(i);
		} else if (((Double) i[0]).doubleValue() > 452.0) {
			p = 6;
		} 
		return p;
	}
	static double N5cdf7665129(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 5;
		} else if (((Double) i[1]).doubleValue() <= 0.195745) {
			p = WekaClassifier1.N52d61085130(i);
		} else if (((Double) i[1]).doubleValue() > 0.195745) {
			p = 6;
		} 
		return p;
	}
	static double N52d61085130(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 5;
		} else if (((Double) i[1]).doubleValue() <= 0.163121) {
			p = 5;
		} else if (((Double) i[1]).doubleValue() > 0.163121) {
			p = WekaClassifier1.N63d6b63f131(i);
		} 
		return p;
	}
	static double N63d6b63f131(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 5;
		} else if (((Double) i[0]).doubleValue() <= 449.0) {
			p = WekaClassifier1.N2557154e132(i);
		} else if (((Double) i[0]).doubleValue() > 449.0) {
			p = WekaClassifier1.N401a5c05135(i);
		} 
		return p;
	}
	static double N2557154e132(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() <= 0.191489) {
			p = WekaClassifier1.N7837c708133(i);
		} else if (((Double) i[1]).doubleValue() > 0.191489) {
			p = 5;
		} 
		return p;
	}
	static double N7837c708133(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 5;
		} else if (((Double) i[1]).doubleValue() <= 0.187234) {
			p = WekaClassifier1.N15ec1be1134(i);
		} else if (((Double) i[1]).doubleValue() > 0.187234) {
			p = 6;
		} 
		return p;
	}
	static double N15ec1be1134(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() <= 0.168794) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() > 0.168794) {
			p = 5;
		} 
		return p;
	}
	static double N401a5c05135(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() <= 0.175887) {
			p = WekaClassifier1.N28f6d24136(i);
		} else if (((Double) i[1]).doubleValue() > 0.175887) {
			p = 1;
		} 
		return p;
	}
	static double N28f6d24136(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() <= 451.0) {
			p = WekaClassifier1.N164657cc137(i);
		} else if (((Double) i[0]).doubleValue() > 451.0) {
			p = 6;
		} 
		return p;
	}
	static double N164657cc137(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 5;
		} else if (((Double) i[1]).doubleValue() <= 0.168794) {
			p = 5;
		} else if (((Double) i[1]).doubleValue() > 0.168794) {
			p = 3;
		} 
		return p;
	}
	static double N642e1d80138(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() <= 0.38156) {
			p = WekaClassifier1.Nf92f1e2139(i);
		} else if (((Double) i[1]).doubleValue() > 0.38156) {
			p = 3;
		} 
		return p;
	}
	static double Nf92f1e2139(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 460.0) {
			p = WekaClassifier1.N7846346a140(i);
		} else if (((Double) i[0]).doubleValue() > 460.0) {
			p = WekaClassifier1.N491b58d6141(i);
		} 
		return p;
	}
	static double N7846346a140(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() <= 0.360284) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() > 0.360284) {
			p = 1;
		} 
		return p;
	}
	static double N491b58d6141(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() <= 0.319149) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() > 0.319149) {
			p = 3;
		} 
		return p;
	}
	static double N22656f19142(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 619.0) {
			p = WekaClassifier1.N3160e3f3143(i);
		} else if (((Double) i[0]).doubleValue() > 619.0) {
			p = WekaClassifier1.N11c7d2e3169(i);
		} 
		return p;
	}
	static double N3160e3f3143(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() <= 0.331915) {
			p = WekaClassifier1.N50157fd8144(i);
		} else if (((Double) i[1]).doubleValue() > 0.331915) {
			p = WekaClassifier1.N68a6a426166(i);
		} 
		return p;
	}
	static double N50157fd8144(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 6;
		} else if (((Double) i[0]).doubleValue() <= 502.0) {
			p = WekaClassifier1.N337c66fb145(i);
		} else if (((Double) i[0]).doubleValue() > 502.0) {
			p = WekaClassifier1.N17ace898164(i);
		} 
		return p;
	}
	static double N337c66fb145(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() <= 0.150355) {
			p = WekaClassifier1.N2c4d0325146(i);
		} else if (((Double) i[1]).doubleValue() > 0.150355) {
			p = WekaClassifier1.N1042ce9b150(i);
		} 
		return p;
	}
	static double N2c4d0325146(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 485.0) {
			p = WekaClassifier1.N740988db147(i);
		} else if (((Double) i[0]).doubleValue() > 485.0) {
			p = WekaClassifier1.N1df81d61148(i);
		} 
		return p;
	}
	static double N740988db147(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() <= 481.0) {
			p = 2;
		} else if (((Double) i[0]).doubleValue() > 481.0) {
			p = 1;
		} 
		return p;
	}
	static double N1df81d61148(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() <= 501.0) {
			p = WekaClassifier1.Nc50daa6149(i);
		} else if (((Double) i[0]).doubleValue() > 501.0) {
			p = 3;
		} 
		return p;
	}
	static double Nc50daa6149(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() <= 0.120567) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() > 0.120567) {
			p = 3;
		} 
		return p;
	}
	static double N1042ce9b150(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() <= 0.24539) {
			p = WekaClassifier1.N120a2a74151(i);
		} else if (((Double) i[1]).doubleValue() > 0.24539) {
			p = WekaClassifier1.N3f974f36159(i);
		} 
		return p;
	}
	static double N120a2a74151(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() <= 0.178723) {
			p = WekaClassifier1.N59692eec152(i);
		} else if (((Double) i[1]).doubleValue() > 0.178723) {
			p = 6;
		} 
		return p;
	}
	static double N59692eec152(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() <= 0.174468) {
			p = WekaClassifier1.N887b5d0153(i);
		} else if (((Double) i[1]).doubleValue() > 0.174468) {
			p = 1;
		} 
		return p;
	}
	static double N887b5d0153(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 6;
		} else if (((Double) i[0]).doubleValue() <= 483.0) {
			p = WekaClassifier1.N5b16f10154(i);
		} else if (((Double) i[0]).doubleValue() > 483.0) {
			p = WekaClassifier1.N43f2865b155(i);
		} 
		return p;
	}
	static double N5b16f10154(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 3;
		} else if (((Double) i[1]).doubleValue() <= 0.167376) {
			p = 3;
		} else if (((Double) i[1]).doubleValue() > 0.167376) {
			p = 6;
		} 
		return p;
	}
	static double N43f2865b155(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() <= 0.167376) {
			p = WekaClassifier1.N6752e336156(i);
		} else if (((Double) i[1]).doubleValue() > 0.167376) {
			p = WekaClassifier1.N693d6c64158(i);
		} 
		return p;
	}
	static double N6752e336156(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 486.0) {
			p = WekaClassifier1.N72c32338157(i);
		} else if (((Double) i[0]).doubleValue() > 486.0) {
			p = 6;
		} 
		return p;
	}
	static double N72c32338157(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() <= 0.15461) {
			p = 6;
		} else if (((Double) i[1]).doubleValue() > 0.15461) {
			p = 1;
		} 
		return p;
	}
	static double N693d6c64158(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 491.0) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() > 491.0) {
			p = 3;
		} 
		return p;
	}
	static double N3f974f36159(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 496.0) {
			p = WekaClassifier1.N66d182d7160(i);
		} else if (((Double) i[0]).doubleValue() > 496.0) {
			p = 1;
		} 
		return p;
	}
	static double N66d182d7160(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 3;
		} else if (((Double) i[1]).doubleValue() <= 0.304965) {
			p = WekaClassifier1.N44e525fd161(i);
		} else if (((Double) i[1]).doubleValue() > 0.304965) {
			p = 1;
		} 
		return p;
	}
	static double N44e525fd161(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() <= 0.253901) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() > 0.253901) {
			p = WekaClassifier1.N20212861162(i);
		} 
		return p;
	}
	static double N20212861162(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() <= 481.0) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() > 481.0) {
			p = WekaClassifier1.N60e208c1163(i);
		} 
		return p;
	}
	static double N60e208c1163(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 490.0) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() > 490.0) {
			p = 3;
		} 
		return p;
	}
	static double N17ace898164(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 3;
		} else if (((Double) i[1]).doubleValue() <= 0.148936) {
			p = WekaClassifier1.N58da5f4c165(i);
		} else if (((Double) i[1]).doubleValue() > 0.148936) {
			p = 1;
		} 
		return p;
	}
	static double N58da5f4c165(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() <= 0.126241) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() > 0.126241) {
			p = 3;
		} 
		return p;
	}
	static double N68a6a426166(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() <= 540.0) {
			p = 3;
		} else if (((Double) i[0]).doubleValue() > 540.0) {
			p = WekaClassifier1.N1462f077167(i);
		} 
		return p;
	}
	static double N1462f077167(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 0;
		} else if (((Double) i[0]).doubleValue() <= 590.0) {
			p = WekaClassifier1.N6b991f15168(i);
		} else if (((Double) i[0]).doubleValue() > 590.0) {
			p = 0;
		} 
		return p;
	}
	static double N6b991f15168(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 0;
		} else if (((Double) i[0]).doubleValue() <= 547.0) {
			p = 0;
		} else if (((Double) i[0]).doubleValue() > 547.0) {
			p = 3;
		} 
		return p;
	}
	static double N11c7d2e3169(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 0;
		} else if (((Double) i[1]).doubleValue() <= 0.208511) {
			p = WekaClassifier1.N55e63e33170(i);
		} else if (((Double) i[1]).doubleValue() > 0.208511) {
			p = 0;
		} 
		return p;
	}
	static double N55e63e33170(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 649.0) {
			p = WekaClassifier1.N7efdb253171(i);
		} else if (((Double) i[0]).doubleValue() > 649.0) {
			p = WekaClassifier1.N41c6a847172(i);
		} 
		return p;
	}
	static double N7efdb253171(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() <= 0.197163) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() > 0.197163) {
			p = 3;
		} 
		return p;
	}
	static double N41c6a847172(Object []i) {
		double p = Double.NaN;
		if (i[0] == null) {
			p = 1;
		} else if (((Double) i[0]).doubleValue() <= 673.0) {
			p = WekaClassifier1.N5951ef0d173(i);
		} else if (((Double) i[0]).doubleValue() > 673.0) {
			p = 0;
		} 
		return p;
	}
	static double N5951ef0d173(Object []i) {
		double p = Double.NaN;
		if (i[1] == null) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() <= 0.185816) {
			p = 1;
		} else if (((Double) i[1]).doubleValue() > 0.185816) {
			p = 0;
		} 
		return p;
	}
}
