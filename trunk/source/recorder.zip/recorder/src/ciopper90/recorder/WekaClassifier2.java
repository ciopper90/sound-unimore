package ciopper90.recorder;

public class WekaClassifier2 {

	  public static String classify(Object[] i)
	    throws Exception {
			double p = Double.NaN;
			String [] elemento={"parco","lezione","treno","tv","auto","ristorante","strada"};
			p = WekaClassifier2.N2cee336e0(i);
			return elemento[(int) p];  
	  }
	  static double N2cee336e0(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 4;
	    } else if (((Double) i[1]).doubleValue() <= 0.10922) {
	    p = WekaClassifier2.N4a7291cd1(i);
	    } else if (((Double) i[1]).doubleValue() > 0.10922) {
	    p = WekaClassifier2.N3002056b23(i);
	    } 
	    return p;
	  }
	  static double N4a7291cd1(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 4;
	    } else if (((Double) i[0]).doubleValue() <= 542.0) {
	    p = WekaClassifier2.N27c24fea2(i);
	    } else if (((Double) i[0]).doubleValue() > 542.0) {
	    p = WekaClassifier2.Neff730419(i);
	    } 
	    return p;
	  }
	  static double N27c24fea2(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 4;
	    } else if (((Double) i[1]).doubleValue() <= 0.056738) {
	    p = WekaClassifier2.N460ca00a3(i);
	    } else if (((Double) i[1]).doubleValue() > 0.056738) {
	    p = WekaClassifier2.N1bc349fa12(i);
	    } 
	    return p;
	  }
	  static double N460ca00a3(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 4;
	    } else if (((Double) i[0]).doubleValue() <= 415.0) {
	    p = WekaClassifier2.N66df14734(i);
	    } else if (((Double) i[0]).doubleValue() > 415.0) {
	    p = WekaClassifier2.N7aea369a10(i);
	    } 
	    return p;
	  }
	  static double N66df14734(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 4;
	    } else if (((Double) i[1]).doubleValue() <= 0.049645) {
	    p = WekaClassifier2.N3fb7bec85(i);
	    } else if (((Double) i[1]).doubleValue() > 0.049645) {
	    p = WekaClassifier2.N61b80f249(i);
	    } 
	    return p;
	  }
	  static double N3fb7bec85(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 4;
	    } else if (((Double) i[0]).doubleValue() <= 379.0) {
	      p = 4;
	    } else if (((Double) i[0]).doubleValue() > 379.0) {
	    p = WekaClassifier2.N384e5d266(i);
	    } 
	    return p;
	  }
	  static double N384e5d266(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 2;
	    } else if (((Double) i[0]).doubleValue() <= 401.0) {
	    p = WekaClassifier2.N20c586ab7(i);
	    } else if (((Double) i[0]).doubleValue() > 401.0) {
	      p = 4;
	    } 
	    return p;
	  }
	  static double N20c586ab7(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 2;
	    } else if (((Double) i[1]).doubleValue() <= 0.029787) {
	    p = WekaClassifier2.N80c555c8(i);
	    } else if (((Double) i[1]).doubleValue() > 0.029787) {
	      p = 2;
	    } 
	    return p;
	  }
	  static double N80c555c8(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 2;
	    } else if (((Double) i[1]).doubleValue() <= 0.025532) {
	      p = 2;
	    } else if (((Double) i[1]).doubleValue() > 0.025532) {
	      p = 4;
	    } 
	    return p;
	  }
	  static double N61b80f249(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 3;
	    } else if (((Double) i[0]).doubleValue() <= 399.0) {
	      p = 3;
	    } else if (((Double) i[0]).doubleValue() > 399.0) {
	      p = 2;
	    } 
	    return p;
	  }
	  static double N7aea369a10(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 4;
	    } else if (((Double) i[1]).doubleValue() <= 0.051064) {
	      p = 4;
	    } else if (((Double) i[1]).doubleValue() > 0.051064) {
	    p = WekaClassifier2.N26a6f78111(i);
	    } 
	    return p;
	  }
	  static double N26a6f78111(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 2;
	    } else if (((Double) i[0]).doubleValue() <= 429.0) {
	      p = 2;
	    } else if (((Double) i[0]).doubleValue() > 429.0) {
	      p = 4;
	    } 
	    return p;
	  }
	  static double N1bc349fa12(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 2;
	    } else if (((Double) i[0]).doubleValue() <= 477.0) {
	      p = 2;
	    } else if (((Double) i[0]).doubleValue() > 477.0) {
	    p = WekaClassifier2.N322dca5313(i);
	    } 
	    return p;
	  }
	  static double N322dca5313(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 4;
	    } else if (((Double) i[1]).doubleValue() <= 0.075177) {
	      p = 4;
	    } else if (((Double) i[1]).doubleValue() > 0.075177) {
	    p = WekaClassifier2.N5c3e28e114(i);
	    } 
	    return p;
	  }
	  static double N5c3e28e114(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 1;
	    } else if (((Double) i[0]).doubleValue() <= 490.0) {
	    p = WekaClassifier2.N74edfb1615(i);
	    } else if (((Double) i[0]).doubleValue() > 490.0) {
	    p = WekaClassifier2.N52b1ced017(i);
	    } 
	    return p;
	  }
	  static double N74edfb1615(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 1;
	    } else if (((Double) i[0]).doubleValue() <= 487.0) {
	    p = WekaClassifier2.N33ff9d5316(i);
	    } else if (((Double) i[0]).doubleValue() > 487.0) {
	      p = 4;
	    } 
	    return p;
	  }
	  static double N33ff9d5316(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 2;
	    } else if (((Double) i[0]).doubleValue() <= 484.0) {
	      p = 2;
	    } else if (((Double) i[0]).doubleValue() > 484.0) {
	      p = 1;
	    } 
	    return p;
	  }
	  static double N52b1ced017(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 3;
	    } else if (((Double) i[1]).doubleValue() <= 0.100709) {
	      p = 3;
	    } else if (((Double) i[1]).doubleValue() > 0.100709) {
	    p = WekaClassifier2.N1780e41a18(i);
	    } 
	    return p;
	  }
	  static double N1780e41a18(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 1;
	    } else if (((Double) i[0]).doubleValue() <= 514.0) {
	      p = 1;
	    } else if (((Double) i[0]).doubleValue() > 514.0) {
	      p = 3;
	    } 
	    return p;
	  }
	  static double Neff730419(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 3;
	    } else if (((Double) i[0]).doubleValue() <= 682.0) {
	    p = WekaClassifier2.N24d8134d20(i);
	    } else if (((Double) i[0]).doubleValue() > 682.0) {
	    p = WekaClassifier2.N1b004a1e22(i);
	    } 
	    return p;
	  }
	  static double N24d8134d20(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 3;
	    } else if (((Double) i[0]).doubleValue() <= 647.0) {
	      p = 3;
	    } else if (((Double) i[0]).doubleValue() > 647.0) {
	    p = WekaClassifier2.N65db372021(i);
	    } 
	    return p;
	  }
	  static double N65db372021(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 1;
	    } else if (((Double) i[0]).doubleValue() <= 674.0) {
	      p = 1;
	    } else if (((Double) i[0]).doubleValue() > 674.0) {
	      p = 3;
	    } 
	    return p;
	  }
	  static double N1b004a1e22(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 3;
	    } else if (((Double) i[0]).doubleValue() <= 690.0) {
	      p = 3;
	    } else if (((Double) i[0]).doubleValue() > 690.0) {
	      p = 0;
	    } 
	    return p;
	  }
	  static double N3002056b23(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 5;
	    } else if (((Double) i[0]).doubleValue() <= 474.0) {
	    p = WekaClassifier2.N54b1cc6c24(i);
	    } else if (((Double) i[0]).doubleValue() > 474.0) {
	    p = WekaClassifier2.N352c11d55(i);
	    } 
	    return p;
	  }
	  static double N54b1cc6c24(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 5;
	    } else if (((Double) i[0]).doubleValue() <= 442.0) {
	    p = WekaClassifier2.N64e3f1e425(i);
	    } else if (((Double) i[0]).doubleValue() > 442.0) {
	    p = WekaClassifier2.N19365cee29(i);
	    } 
	    return p;
	  }
	  static double N64e3f1e425(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 2;
	    } else if (((Double) i[1]).doubleValue() <= 0.148936) {
	    p = WekaClassifier2.N311de37b26(i);
	    } else if (((Double) i[1]).doubleValue() > 0.148936) {
	      p = 5;
	    } 
	    return p;
	  }
	  static double N311de37b26(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 2;
	    } else if (((Double) i[1]).doubleValue() <= 0.139007) {
	      p = 2;
	    } else if (((Double) i[1]).doubleValue() > 0.139007) {
	    p = WekaClassifier2.N2141b96e27(i);
	    } 
	    return p;
	  }
	  static double N2141b96e27(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 5;
	    } else if (((Double) i[0]).doubleValue() <= 422.0) {
	      p = 5;
	    } else if (((Double) i[0]).doubleValue() > 422.0) {
	    p = WekaClassifier2.N61f4f5d028(i);
	    } 
	    return p;
	  }
	  static double N61f4f5d028(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 2;
	    } else if (((Double) i[0]).doubleValue() <= 434.0) {
	      p = 2;
	    } else if (((Double) i[0]).doubleValue() > 434.0) {
	      p = 5;
	    } 
	    return p;
	  }
	  static double N19365cee29(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 2;
	    } else if (((Double) i[1]).doubleValue() <= 0.15461) {
	    p = WekaClassifier2.N400f1a3030(i);
	    } else if (((Double) i[1]).doubleValue() > 0.15461) {
	    p = WekaClassifier2.N5393c04940(i);
	    } 
	    return p;
	  }
	  static double N400f1a3030(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 2;
	    } else if (((Double) i[1]).doubleValue() <= 0.113475) {
	    p = WekaClassifier2.N1f80662b31(i);
	    } else if (((Double) i[1]).doubleValue() > 0.113475) {
	    p = WekaClassifier2.N5b1cb26c33(i);
	    } 
	    return p;
	  }
	  static double N1f80662b31(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 2;
	    } else if (((Double) i[1]).doubleValue() <= 0.112057) {
	      p = 2;
	    } else if (((Double) i[1]).doubleValue() > 0.112057) {
	    p = WekaClassifier2.N26b3a13532(i);
	    } 
	    return p;
	  }
	  static double N26b3a13532(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 3;
	    } else if (((Double) i[0]).doubleValue() <= 467.0) {
	      p = 3;
	    } else if (((Double) i[0]).doubleValue() > 467.0) {
	      p = 2;
	    } 
	    return p;
	  }
	  static double N5b1cb26c33(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 2;
	    } else if (((Double) i[1]).doubleValue() <= 0.147518) {
	    p = WekaClassifier2.N3905ff2f34(i);
	    } else if (((Double) i[1]).doubleValue() > 0.147518) {
	    p = WekaClassifier2.N30d6847b39(i);
	    } 
	    return p;
	  }
	  static double N3905ff2f34(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 2;
	    } else if (((Double) i[0]).doubleValue() <= 462.0) {
	    p = WekaClassifier2.N38b483e835(i);
	    } else if (((Double) i[0]).doubleValue() > 462.0) {
	    p = WekaClassifier2.N5340116d36(i);
	    } 
	    return p;
	  }
	  static double N38b483e835(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 6;
	    } else if (((Double) i[1]).doubleValue() <= 0.114894) {
	      p = 6;
	    } else if (((Double) i[1]).doubleValue() > 0.114894) {
	      p = 2;
	    } 
	    return p;
	  }
	  static double N5340116d36(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 1;
	    } else if (((Double) i[0]).doubleValue() <= 465.0) {
	      p = 1;
	    } else if (((Double) i[0]).doubleValue() > 465.0) {
	    p = WekaClassifier2.N133835ce37(i);
	    } 
	    return p;
	  }
	  static double N133835ce37(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 1;
	    } else if (((Double) i[1]).doubleValue() <= 0.139007) {
	    p = WekaClassifier2.N4f54713d38(i);
	    } else if (((Double) i[1]).doubleValue() > 0.139007) {
	      p = 6;
	    } 
	    return p;
	  }
	  static double N4f54713d38(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 6;
	    } else if (((Double) i[1]).doubleValue() <= 0.130496) {
	      p = 6;
	    } else if (((Double) i[1]).doubleValue() > 0.130496) {
	      p = 1;
	    } 
	    return p;
	  }
	  static double N30d6847b39(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 3;
	    } else if (((Double) i[0]).doubleValue() <= 460.0) {
	      p = 3;
	    } else if (((Double) i[0]).doubleValue() > 460.0) {
	      p = 2;
	    } 
	    return p;
	  }
	  static double N5393c04940(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 6;
	    } else if (((Double) i[1]).doubleValue() <= 0.313475) {
	    p = WekaClassifier2.N935237d41(i);
	    } else if (((Double) i[1]).doubleValue() > 0.313475) {
	    p = WekaClassifier2.N7938d3fb51(i);
	    } 
	    return p;
	  }
	  static double N935237d41(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 6;
	    } else if (((Double) i[0]).doubleValue() <= 452.0) {
	    p = WekaClassifier2.N7face84342(i);
	    } else if (((Double) i[0]).doubleValue() > 452.0) {
	      p = 6;
	    } 
	    return p;
	  }
	  static double N7face84342(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 5;
	    } else if (((Double) i[1]).doubleValue() <= 0.195745) {
	    p = WekaClassifier2.N30c4c83143(i);
	    } else if (((Double) i[1]).doubleValue() > 0.195745) {
	      p = 6;
	    } 
	    return p;
	  }
	  static double N30c4c83143(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 5;
	    } else if (((Double) i[1]).doubleValue() <= 0.163121) {
	      p = 5;
	    } else if (((Double) i[1]).doubleValue() > 0.163121) {
	    p = WekaClassifier2.N473321fa44(i);
	    } 
	    return p;
	  }
	  static double N473321fa44(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 5;
	    } else if (((Double) i[0]).doubleValue() <= 449.0) {
	    p = WekaClassifier2.N6dfbc89a45(i);
	    } else if (((Double) i[0]).doubleValue() > 449.0) {
	    p = WekaClassifier2.N5e652b7b48(i);
	    } 
	    return p;
	  }
	  static double N6dfbc89a45(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 6;
	    } else if (((Double) i[1]).doubleValue() <= 0.191489) {
	    p = WekaClassifier2.N2d2f2edf46(i);
	    } else if (((Double) i[1]).doubleValue() > 0.191489) {
	      p = 5;
	    } 
	    return p;
	  }
	  static double N2d2f2edf46(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 5;
	    } else if (((Double) i[1]).doubleValue() <= 0.187234) {
	    p = WekaClassifier2.N74ae49a547(i);
	    } else if (((Double) i[1]).doubleValue() > 0.187234) {
	      p = 6;
	    } 
	    return p;
	  }
	  static double N74ae49a547(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 6;
	    } else if (((Double) i[1]).doubleValue() <= 0.168794) {
	      p = 6;
	    } else if (((Double) i[1]).doubleValue() > 0.168794) {
	      p = 5;
	    } 
	    return p;
	  }
	  static double N5e652b7b48(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 6;
	    } else if (((Double) i[1]).doubleValue() <= 0.175887) {
	    p = WekaClassifier2.N4409c8a749(i);
	    } else if (((Double) i[1]).doubleValue() > 0.175887) {
	      p = 1;
	    } 
	    return p;
	  }
	  static double N4409c8a749(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 3;
	    } else if (((Double) i[0]).doubleValue() <= 451.0) {
	    p = WekaClassifier2.N5e546ed650(i);
	    } else if (((Double) i[0]).doubleValue() > 451.0) {
	      p = 6;
	    } 
	    return p;
	  }
	  static double N5e546ed650(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 5;
	    } else if (((Double) i[1]).doubleValue() <= 0.168794) {
	      p = 5;
	    } else if (((Double) i[1]).doubleValue() > 0.168794) {
	      p = 3;
	    } 
	    return p;
	  }
	  static double N7938d3fb51(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 1;
	    } else if (((Double) i[1]).doubleValue() <= 0.38156) {
	    p = WekaClassifier2.N1e541ea52(i);
	    } else if (((Double) i[1]).doubleValue() > 0.38156) {
	      p = 3;
	    } 
	    return p;
	  }
	  static double N1e541ea52(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 1;
	    } else if (((Double) i[0]).doubleValue() <= 460.0) {
	    p = WekaClassifier2.N724a6a9e53(i);
	    } else if (((Double) i[0]).doubleValue() > 460.0) {
	    p = WekaClassifier2.N739de5b054(i);
	    } 
	    return p;
	  }
	  static double N724a6a9e53(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 6;
	    } else if (((Double) i[1]).doubleValue() <= 0.360284) {
	      p = 6;
	    } else if (((Double) i[1]).doubleValue() > 0.360284) {
	      p = 1;
	    } 
	    return p;
	  }
	  static double N739de5b054(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 1;
	    } else if (((Double) i[1]).doubleValue() <= 0.319149) {
	      p = 1;
	    } else if (((Double) i[1]).doubleValue() > 0.319149) {
	      p = 3;
	    } 
	    return p;
	  }
	  static double N352c11d55(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 1;
	    } else if (((Double) i[0]).doubleValue() <= 619.0) {
	    p = WekaClassifier2.N2e04589f56(i);
	    } else if (((Double) i[0]).doubleValue() > 619.0) {
	    p = WekaClassifier2.N7185917082(i);
	    } 
	    return p;
	  }
	  static double N2e04589f56(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 1;
	    } else if (((Double) i[1]).doubleValue() <= 0.331915) {
	    p = WekaClassifier2.N1f56465357(i);
	    } else if (((Double) i[1]).doubleValue() > 0.331915) {
	    p = WekaClassifier2.N1848173a79(i);
	    } 
	    return p;
	  }
	  static double N1f56465357(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 6;
	    } else if (((Double) i[0]).doubleValue() <= 502.0) {
	    p = WekaClassifier2.N5923033758(i);
	    } else if (((Double) i[0]).doubleValue() > 502.0) {
	    p = WekaClassifier2.N7e7ef84a77(i);
	    } 
	    return p;
	  }
	  static double N5923033758(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 1;
	    } else if (((Double) i[1]).doubleValue() <= 0.150355) {
	    p = WekaClassifier2.N9a83d9959(i);
	    } else if (((Double) i[1]).doubleValue() > 0.150355) {
	    p = WekaClassifier2.N34182bd563(i);
	    } 
	    return p;
	  }
	  static double N9a83d9959(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 1;
	    } else if (((Double) i[0]).doubleValue() <= 485.0) {
	    p = WekaClassifier2.N4640cc360(i);
	    } else if (((Double) i[0]).doubleValue() > 485.0) {
	    p = WekaClassifier2.N4481d87561(i);
	    } 
	    return p;
	  }
	  static double N4640cc360(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 2;
	    } else if (((Double) i[0]).doubleValue() <= 481.0) {
	      p = 2;
	    } else if (((Double) i[0]).doubleValue() > 481.0) {
	      p = 1;
	    } 
	    return p;
	  }
	  static double N4481d87561(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 3;
	    } else if (((Double) i[0]).doubleValue() <= 501.0) {
	    p = WekaClassifier2.N28aa0c7662(i);
	    } else if (((Double) i[0]).doubleValue() > 501.0) {
	      p = 3;
	    } 
	    return p;
	  }
	  static double N28aa0c7662(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 1;
	    } else if (((Double) i[1]).doubleValue() <= 0.120567) {
	      p = 1;
	    } else if (((Double) i[1]).doubleValue() > 0.120567) {
	      p = 3;
	    } 
	    return p;
	  }
	  static double N34182bd563(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 6;
	    } else if (((Double) i[1]).doubleValue() <= 0.24539) {
	    p = WekaClassifier2.N1ee5c7ab64(i);
	    } else if (((Double) i[1]).doubleValue() > 0.24539) {
	    p = WekaClassifier2.N5ef1ca5172(i);
	    } 
	    return p;
	  }
	  static double N1ee5c7ab64(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 6;
	    } else if (((Double) i[1]).doubleValue() <= 0.178723) {
	    p = WekaClassifier2.N7f97bb6565(i);
	    } else if (((Double) i[1]).doubleValue() > 0.178723) {
	      p = 6;
	    } 
	    return p;
	  }
	  static double N7f97bb6565(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 6;
	    } else if (((Double) i[1]).doubleValue() <= 0.174468) {
	    p = WekaClassifier2.N4290255466(i);
	    } else if (((Double) i[1]).doubleValue() > 0.174468) {
	      p = 1;
	    } 
	    return p;
	  }
	  static double N4290255466(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 6;
	    } else if (((Double) i[0]).doubleValue() <= 483.0) {
	    p = WekaClassifier2.N582cff067(i);
	    } else if (((Double) i[0]).doubleValue() > 483.0) {
	    p = WekaClassifier2.N4f21986368(i);
	    } 
	    return p;
	  }
	  static double N582cff067(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 3;
	    } else if (((Double) i[1]).doubleValue() <= 0.167376) {
	      p = 3;
	    } else if (((Double) i[1]).doubleValue() > 0.167376) {
	      p = 6;
	    } 
	    return p;
	  }
	  static double N4f21986368(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 6;
	    } else if (((Double) i[1]).doubleValue() <= 0.167376) {
	    p = WekaClassifier2.N269bb42b69(i);
	    } else if (((Double) i[1]).doubleValue() > 0.167376) {
	    p = WekaClassifier2.N706c6f1871(i);
	    } 
	    return p;
	  }
	  static double N269bb42b69(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 1;
	    } else if (((Double) i[0]).doubleValue() <= 486.0) {
	    p = WekaClassifier2.N385186da70(i);
	    } else if (((Double) i[0]).doubleValue() > 486.0) {
	      p = 6;
	    } 
	    return p;
	  }
	  static double N385186da70(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 6;
	    } else if (((Double) i[1]).doubleValue() <= 0.15461) {
	      p = 6;
	    } else if (((Double) i[1]).doubleValue() > 0.15461) {
	      p = 1;
	    } 
	    return p;
	  }
	  static double N706c6f1871(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 1;
	    } else if (((Double) i[0]).doubleValue() <= 491.0) {
	      p = 1;
	    } else if (((Double) i[0]).doubleValue() > 491.0) {
	      p = 3;
	    } 
	    return p;
	  }
	  static double N5ef1ca5172(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 1;
	    } else if (((Double) i[0]).doubleValue() <= 496.0) {
	    p = WekaClassifier2.N5419bc8973(i);
	    } else if (((Double) i[0]).doubleValue() > 496.0) {
	      p = 1;
	    } 
	    return p;
	  }
	  static double N5419bc8973(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 3;
	    } else if (((Double) i[1]).doubleValue() <= 0.304965) {
	    p = WekaClassifier2.N65a8f18174(i);
	    } else if (((Double) i[1]).doubleValue() > 0.304965) {
	      p = 1;
	    } 
	    return p;
	  }
	  static double N65a8f18174(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 1;
	    } else if (((Double) i[1]).doubleValue() <= 0.253901) {
	      p = 1;
	    } else if (((Double) i[1]).doubleValue() > 0.253901) {
	    p = WekaClassifier2.N3687804b75(i);
	    } 
	    return p;
	  }
	  static double N3687804b75(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 3;
	    } else if (((Double) i[0]).doubleValue() <= 481.0) {
	      p = 3;
	    } else if (((Double) i[0]).doubleValue() > 481.0) {
	    p = WekaClassifier2.N79f7d7e476(i);
	    } 
	    return p;
	  }
	  static double N79f7d7e476(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 1;
	    } else if (((Double) i[0]).doubleValue() <= 490.0) {
	      p = 1;
	    } else if (((Double) i[0]).doubleValue() > 490.0) {
	      p = 3;
	    } 
	    return p;
	  }
	  static double N7e7ef84a77(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 3;
	    } else if (((Double) i[1]).doubleValue() <= 0.148936) {
	    p = WekaClassifier2.N41df032778(i);
	    } else if (((Double) i[1]).doubleValue() > 0.148936) {
	      p = 1;
	    } 
	    return p;
	  }
	  static double N41df032778(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 1;
	    } else if (((Double) i[1]).doubleValue() <= 0.126241) {
	      p = 1;
	    } else if (((Double) i[1]).doubleValue() > 0.126241) {
	      p = 3;
	    } 
	    return p;
	  }
	  static double N1848173a79(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 3;
	    } else if (((Double) i[0]).doubleValue() <= 540.0) {
	      p = 3;
	    } else if (((Double) i[0]).doubleValue() > 540.0) {
	    p = WekaClassifier2.N24eced4a80(i);
	    } 
	    return p;
	  }
	  static double N24eced4a80(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 0;
	    } else if (((Double) i[0]).doubleValue() <= 590.0) {
	    p = WekaClassifier2.N3ecea83681(i);
	    } else if (((Double) i[0]).doubleValue() > 590.0) {
	      p = 0;
	    } 
	    return p;
	  }
	  static double N3ecea83681(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 0;
	    } else if (((Double) i[0]).doubleValue() <= 547.0) {
	      p = 0;
	    } else if (((Double) i[0]).doubleValue() > 547.0) {
	      p = 3;
	    } 
	    return p;
	  }
	  static double N7185917082(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 0;
	    } else if (((Double) i[1]).doubleValue() <= 0.208511) {
	    p = WekaClassifier2.N780f8a4983(i);
	    } else if (((Double) i[1]).doubleValue() > 0.208511) {
	      p = 0;
	    } 
	    return p;
	  }
	  static double N780f8a4983(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 1;
	    } else if (((Double) i[0]).doubleValue() <= 649.0) {
	    p = WekaClassifier2.N443ffc3384(i);
	    } else if (((Double) i[0]).doubleValue() > 649.0) {
	    p = WekaClassifier2.N44c69b4685(i);
	    } 
	    return p;
	  }
	  static double N443ffc3384(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 1;
	    } else if (((Double) i[1]).doubleValue() <= 0.197163) {
	      p = 1;
	    } else if (((Double) i[1]).doubleValue() > 0.197163) {
	      p = 3;
	    } 
	    return p;
	  }
	  static double N44c69b4685(Object []i) {
	    double p = Double.NaN;
	    if (i[0] == null) {
	      p = 1;
	    } else if (((Double) i[0]).doubleValue() <= 673.0) {
	    p = WekaClassifier2.N4afc33f086(i);
	    } else if (((Double) i[0]).doubleValue() > 673.0) {
	      p = 0;
	    } 
	    return p;
	  }
	  static double N4afc33f086(Object []i) {
	    double p = Double.NaN;
	    if (i[1] == null) {
	      p = 1;
	    } else if (((Double) i[1]).doubleValue() <= 0.185816) {
	      p = 1;
	    } else if (((Double) i[1]).doubleValue() > 0.185816) {
	      p = 0;
	    } 
	    return p;
	  }
	}